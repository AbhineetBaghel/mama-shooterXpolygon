gdjs.game_32overCode = {};
gdjs.game_32overCode.GDBushBackgroundObjects1= [];
gdjs.game_32overCode.GDBushBackgroundObjects2= [];
gdjs.game_32overCode.GDHouseTallForegroundObjects1= [];
gdjs.game_32overCode.GDHouseTallForegroundObjects2= [];
gdjs.game_32overCode.GDHouseSmallBackgroundObjects1= [];
gdjs.game_32overCode.GDHouseSmallBackgroundObjects2= [];
gdjs.game_32overCode.GDPurpleBackgroundObjects1= [];
gdjs.game_32overCode.GDPurpleBackgroundObjects2= [];
gdjs.game_32overCode.GDnoObjects1= [];
gdjs.game_32overCode.GDnoObjects2= [];
gdjs.game_32overCode.GDNFTObjects1= [];
gdjs.game_32overCode.GDNFTObjects2= [];
gdjs.game_32overCode.GDNFT2Objects1= [];
gdjs.game_32overCode.GDNFT2Objects2= [];

gdjs.game_32overCode.conditionTrue_0 = {val:false};
gdjs.game_32overCode.condition0IsTrue_0 = {val:false};
gdjs.game_32overCode.condition1IsTrue_0 = {val:false};
gdjs.game_32overCode.condition2IsTrue_0 = {val:false};
gdjs.game_32overCode.condition3IsTrue_0 = {val:false};
gdjs.game_32overCode.conditionTrue_1 = {val:false};
gdjs.game_32overCode.condition0IsTrue_1 = {val:false};
gdjs.game_32overCode.condition1IsTrue_1 = {val:false};
gdjs.game_32overCode.condition2IsTrue_1 = {val:false};
gdjs.game_32overCode.condition3IsTrue_1 = {val:false};


gdjs.game_32overCode.mapOfGDgdjs_46game_9532overCode_46GDNFT2Objects1Objects = Hashtable.newFrom({"NFT2": gdjs.game_32overCode.GDNFT2Objects1});
gdjs.game_32overCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NFT2"), gdjs.game_32overCode.GDNFT2Objects1);

gdjs.game_32overCode.condition0IsTrue_0.val = false;
gdjs.game_32overCode.condition1IsTrue_0.val = false;
gdjs.game_32overCode.condition2IsTrue_0.val = false;
{
gdjs.game_32overCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.game_32overCode.mapOfGDgdjs_46game_9532overCode_46GDNFT2Objects1Objects, runtimeScene, true, false);
}if ( gdjs.game_32overCode.condition0IsTrue_0.val ) {
{
gdjs.game_32overCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.game_32overCode.condition1IsTrue_0.val ) {
{
{gdjs.game_32overCode.conditionTrue_1 = gdjs.game_32overCode.condition2IsTrue_0;
gdjs.game_32overCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12000924);
}
}}
}
if (gdjs.game_32overCode.condition2IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://nft-minter.vercel.app/", runtimeScene);
}}

}


};

gdjs.game_32overCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.game_32overCode.GDBushBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDBushBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDHouseTallForegroundObjects1.length = 0;
gdjs.game_32overCode.GDHouseTallForegroundObjects2.length = 0;
gdjs.game_32overCode.GDHouseSmallBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDHouseSmallBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDPurpleBackgroundObjects1.length = 0;
gdjs.game_32overCode.GDPurpleBackgroundObjects2.length = 0;
gdjs.game_32overCode.GDnoObjects1.length = 0;
gdjs.game_32overCode.GDnoObjects2.length = 0;
gdjs.game_32overCode.GDNFTObjects1.length = 0;
gdjs.game_32overCode.GDNFTObjects2.length = 0;
gdjs.game_32overCode.GDNFT2Objects1.length = 0;
gdjs.game_32overCode.GDNFT2Objects2.length = 0;

gdjs.game_32overCode.eventsList0(runtimeScene);

return;

}

gdjs['game_32overCode'] = gdjs.game_32overCode;
